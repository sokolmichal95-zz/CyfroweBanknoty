/*
import static org.junit.Assert.*;

import org.junit.Test;

public class XorTest {

	@Test
	public void testGetXOR() {
	   byte[] arg = {0,0,1,1};
	   byte[] arg2 = {1,0,1,0};
	  byte[] result =  Utils.Utils.getXOR(arg, arg2);
	  byte[] exp = {1,0,0,1};
	  
	  assertArrayEquals(exp, result);
	  
	}

}
*/